const wisataDetails = {
    'Candi Borobudur': {
        title: 'Candi Borobudur',
        img: 'borobudur.jpg',
        desc: 'Candi Borobudur adalah candi Buddha terbesar di dunia yang terletak di Magelang, Jawa Tengah, Indonesia. Candi ini dibangun pada abad ke-9 oleh dinasti Syailendra.',
        location: 'Magelang, Jawa Tengah',
        hours: '06:00 - 17:00 WIB',
        type: 'budaya'
    },
    'Pantai Kuta, Bali': {
        title: 'Pantai Kuta, Bali',
        img: 'bali.jpg',
        desc: 'Pantai Kuta adalah salah satu pantai paling terkenal di Bali, Indonesia. Pantai ini terkenal dengan pasir putihnya yang lembut dan pemandangan matahari terbenam yang menakjubkan.',
        location: 'Kuta, Bali',
        hours: '24 jam',
        type: 'alam'
    },
    'Taman Nasional Komodo': {
        title: 'Taman Nasional Komodo',
        img: 'komodo.jpg',
        desc: 'Taman Nasional Komodo adalah habitat asli dari komodo, hewan purba yang hanya ada di Indonesia. Taman nasional ini terletak di Nusa Tenggara Timur.',
        location: 'Nusa Tenggara Timur',
        hours: '07:00 - 17:00 WIB',
        type: 'alam'
    },
    'Gunung Bromo': {
        title: 'Gunung Bromo',
        img: 'bromo.jpg',
        desc: 'Gunung berapi aktif yang terkenal dengan pemandangan matahari terbitnya.',
        location: 'Jawa Timur',
        hours: '24 jam',
        type: 'alam'
    },
    'Danau Toba': {
        title: 'Danau Toba',
        img: 'toba.jpg',
        desc: 'Danau vulkanik terbesar di dunia yang terletak di Sumatera Utara.',
        location: 'Sumatera Utara',
        hours: '24 jam',
        type: 'alam'
    },
    'Taman Mini Indonesia Indah': {
        title: 'Taman Mini Indonesia Indah',
        img: 'taman_mini.jpg',
        desc: 'Taman Mini Indonesia Indah (TMII) adalah taman rekreasi yang terletak di Jakarta Timur. TMII memiliki miniatur bangunan dan budaya dari berbagai daerah di Indonesia.',
        location: 'Jakarta Timur',
        hours: '08:00 - 17:00 WIB',
        type: 'budaya'
    },
    'Pulau Komodo': {
        title: 'Pulau Komodo',
        img: 'pulau_komodo.jpg',
        desc: 'Pulau Komodo adalah salah satu pulau di Taman Nasional Komodo yang terkenal dengan keberadaan komodo. Pulau ini menawarkan wisata alam dan diving yang menakjubkan.',
        location: 'Nusa Tenggara Timur',
        hours: '24 jam',
        type: 'alam'
    },
    'Museum Nasional Indonesia': {
        title: 'Museum Nasional Indonesia',
        img: 'museum_nasional.jpg',
        desc: 'Museum Nasional Indonesia, juga dikenal sebagai Museum Gajah, adalah museum arkeologi dan etnografi terbesar di Indonesia. Museum ini terletak di Jakarta Pusat.',
        location: 'Jakarta Pusat',
        hours: '09:00 - 16:00 WIB',
        type: 'budaya'
    },
    'Bunaken Marine Park': {
        title: 'Taman Laut Bunaken',
        img: 'bunaken.jpg',
        desc: 'Taman Laut Bunaken adalah taman laut nasional yang terletak di Utara Pulau Sulawesi, Indonesia. Bunaken terkenal dengan keindahan bawah lautnya yang kaya akan terumbu karang.',
        location: 'Manado, Sulawesi Utara',
        hours: '24 jam',
        type: 'alam'
    },
    'Taman Safari Indonesia': {
        title: 'Taman Safari Indonesia',
        img: 'taman_safari.jpg',
        desc: 'Taman Safari Indonesia adalah taman safari dan taman hiburan yang terletak di Cisarua, Bogor, Jawa Barat. Taman ini menyajikan pengalaman melihat satwa liar dalam habitat yang mirip alaminya.',
        location: 'Bogor, Jawa Barat',
        hours: '09:00 - 17:00 WIB',
        type: 'alam'
    },
    'Taman Wisata Matahari Bogor': {
        title: 'Taman Wisata Matahari Bogor',
        img: 'matahari_bogor.jpg',
        desc: 'Taman Wisata Matahari Bogor adalah sebuah taman rekreasi dan hiburan yang terletak di Kota Bogor, Jawa Barat. Taman ini menawarkan berbagai wahana permainan dan atraksi keluarga.',
        location: 'Bogor, Jawa Barat',
        hours: '10:00 - 22:00 WIB',
        type: 'budaya'
    },
    'Taman Laut Togean': {
        title: 'Taman Laut Togean',
        img: 'togean.jpg',
        desc: 'Taman Laut Togean adalah taman laut yang terletak di Kepulauan Togean, Sulawesi Tengah. Taman ini menawarkan keindahan bawah laut yang belum terjamah.',
        location: 'Kepulauan Togean, Sulawesi Tengah',
        hours: '24 jam',
        type: 'alam'
    }
};
