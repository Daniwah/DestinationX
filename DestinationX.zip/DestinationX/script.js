document.addEventListener('DOMContentLoaded', () => {
    const menuToggle = document.getElementById('menu-toggle');
    const navList = document.getElementById('nav-list');

    menuToggle.addEventListener('click', () => {
        navList.classList.toggle('active');
    });

    function displayWisata(type) {
        const cardsContainer = document.getElementById('wisata-cards');
        cardsContainer.innerHTML = ''; // Clear previous cards

        Object.keys(wisataDetails).forEach(key => {
            if (type === 'all' || wisataDetails[key].type === type) {
                const card = document.createElement('div');
                card.className = 'card';
                card.innerHTML = `
                    <img src="${wisataDetails[key].img}" alt="${wisataDetails[key].title}">
                    <h3>${wisataDetails[key].title}</h3>
                    <p>${wisataDetails[key].desc}</p>
                `;
                card.addEventListener('click', () => showDetail(key));
                cardsContainer.appendChild(card);
            }
        });
    }

    window.filterWisata = (type) => {
        displayWisata(type);
    };

    function showDetail(wisataName) {
        const wisata = wisataDetails[wisataName];
        localStorage.setItem('wisata', JSON.stringify(wisata));
        window.location.href = 'detail.html';
    }

    // Display all wisata on initial load
    displayWisata('all');
});
